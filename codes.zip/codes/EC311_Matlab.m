clear all;
format shortg
clk = clock;

clk = fix(clk(4:6));
s = serialport('COM4', 9600);
s.Timeout = 30;
flush(s)
write(s, clk, 'uint8');

